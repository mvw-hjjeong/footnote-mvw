const svgUrl = 'svgUrl'

export default svgUrl
export const ReactComponent = 'svg'
